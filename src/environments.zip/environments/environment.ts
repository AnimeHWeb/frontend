export const environment = {
  IP_SERVER: 'http://1111111:8081',
  IP_SERVER_RADMIN: 'http://11111111:8081',
};
