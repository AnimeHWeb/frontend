export const googleScriptCheckPaid =
  'https://script.googleusercontent.com/macros....';
